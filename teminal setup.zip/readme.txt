teminal setups
these are to install programs of there oun teminal
there are not malwares
powershell is new
cmd is the current
